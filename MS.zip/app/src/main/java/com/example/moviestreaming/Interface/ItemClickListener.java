package com.example.moviestreaming.Interface;

import android.view.View;

public interface ItemClickListener {

    void onClick(View view);

}
