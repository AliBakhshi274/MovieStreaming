package com.example.moviestreaming.Model;

public class Intro {

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    String id, description, link_img;


    public String getLink_img() {
        return link_img;
    }

    public void setLink_img(String link_img) {
        this.link_img = link_img;
    }


    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
