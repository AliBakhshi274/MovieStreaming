package com.example.moviestreaming.Model;

public class Season {

    String id, id_item, link_img, number_season, count_episode;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getId_item() {
        return id_item;
    }

    public void setId_item(String id_item) {
        this.id_item = id_item;
    }

    public String getLink_img() {
        return link_img;
    }

    public void setLink_img(String link_img) {
        this.link_img = link_img;
    }

    public String getNumber_season() {
        return number_season;
    }

    public void setNumber_season(String number_season) {
        this.number_season = number_season;
    }

    public String getCount_episode() {
        return count_episode;
    }

    public void setCount_episode(String count_episode) {
        this.count_episode = count_episode;
    }
}
