<?php


$connection = mysqli_connect('localhost','root','','moviestreaming');

mysqli_set_charset($connection,"utf8");


//echo "Success";


?>